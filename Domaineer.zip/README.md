# Domaineer
Domain Engineer or Domaineer is Semi-Auto Bot to gaining data from domains

![Image of Screenshot](https://raw.githubusercontent.com/c0del1ar/Domaineer/main/preview-domaineer1361.jpg)

##### How to Install?
```
git clone https://github.com/c0del1ar/Domaineer
cd Domaineer
pip install -r req.txt
python domaineer.py
```

##### Working on
Linux, Windows, Android (Use emulator such as Termux)
